#!/bin/sh

echo "Hello World" >> ~/test.txt
