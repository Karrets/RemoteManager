#!/bin/sh

echo "Hello World" >> ~/TEST.txt
